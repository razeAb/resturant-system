export const ORDER_STATUS = {
  PENDING: "pending",
  PREPARING: "preparing",
  DELIVERING: "delivering",
  DONE: "done",
};
